# hello-world
Papildus teksts, priekš izmaiņām.

Pirmā testa izmēģinājums #1

Otrā testa izmēģinājums #2

Trešā testa izmēģinājums #3